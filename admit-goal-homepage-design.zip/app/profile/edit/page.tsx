"use client"

import { useState } from "react"
import { User, Save, Camera, CheckCircle2 } from "lucide-react"
import { DashboardShell } from "@/components/dashboard-shell"
import { Field, SelectField } from "@/components/form-fields"
import { countries } from "@/lib/data"
import { cn } from "@/lib/utils"

const sections = ["Personal", "Education", "Preferences", "Account"]

const degreeOptions = [
  { value: "bachelor", label: "Bachelor's" },
  { value: "masters", label: "Master's" },
  { value: "phd", label: "PhD" },
]

export default function ProfileEditPage() {
  const [section, setSection] = useState("Personal")
  const [saved, setSaved] = useState(false)

  function handleSave() {
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  return (
    <DashboardShell>
      <div className="mx-auto max-w-4xl">
        <div className="fade-in flex flex-col gap-2">
          <h1 className="flex items-center gap-2 text-2xl font-bold sm:text-3xl">
            <User className="h-7 w-7 text-primary" />
            My Profile
          </h1>
          <p className="text-muted-foreground">Keep your details up to date for the best scholarship matches.</p>
        </div>

        {/* Avatar header */}
        <div className="glass mt-6 flex flex-col items-center gap-4 rounded-3xl p-6 sm:flex-row">
          <div className="relative">
            <div className="gradient-primary flex h-20 w-20 items-center justify-center rounded-full text-2xl font-bold text-primary-foreground">
              AH
            </div>
            <button
              aria-label="Change photo"
              className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full border border-white/15 bg-card transition-all hover:bg-white/10"
            >
              <Camera className="h-4 w-4" />
            </button>
          </div>
          <div className="text-center sm:text-left">
            <h2 className="text-xl font-bold">Ahmed Hassan</h2>
            <p className="text-sm text-muted-foreground">ahmed@email.com</p>
            <div className="mt-2 flex items-center justify-center gap-2 sm:justify-start">
              <div className="h-1.5 w-32 overflow-hidden rounded-full bg-white/10">
                <div className="gradient-primary h-full rounded-full" style={{ width: "75%" }} />
              </div>
              <span className="text-xs text-muted-foreground">75% complete</span>
            </div>
          </div>
        </div>

        {/* Section tabs */}
        <div className="no-scrollbar mt-6 flex gap-2 overflow-x-auto pb-2">
          {sections.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSection(s)}
              className={cn(
                "shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-all duration-300",
                section === s ? "gradient-primary text-primary-foreground" : "glass text-muted-foreground hover:text-foreground",
              )}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="glass-strong mt-4 rounded-3xl p-6 sm:p-8">
          <div className="flex flex-col gap-5">
            {section === "Personal" && (
              <>
                <Field label="Full name" value="Ahmed Hassan" onChange={() => { }} />
                <Field label="Email" type="email" value="ahmed@email.com" onChange={() => { }} />
                <SelectField
                  label="Country of citizenship"
                  options={countries.map((c) => ({ value: c.name, label: `${c.flag} ${c.name}` }))}
                  value="Pakistan"
                  onChange={() => { }}
                />
                <Field label="Phone" type="tel" placeholder="+92 300 0000000" />
              </>
            )}
            {section === "Education" && (
              <>
                <SelectField label="Current level" options={degreeOptions} value="bachelor" onChange={() => { }} />
                <Field label="Field of study" value="Computer Science" onChange={() => { }} />
                <div className="grid grid-cols-2 gap-4">
                  <Field label="GPA" value="3.8 / 4.0" onChange={() => { }} />
                  <Field label="Graduation year" value="2025" onChange={() => { }} />
                </div>
                <Field label="Test scores" placeholder="IELTS 7.5" />
              </>
            )}
            {section === "Preferences" && (
              <>
                <SelectField label="Desired degree" options={degreeOptions} value="masters" onChange={() => { }} />
                <Field label="Preferred countries" value="UK, Germany, Canada" onChange={() => { }} />
                <SelectField
                  label="Funding preference"
                  options={[
                    { value: "full", label: "Fully Funded only" },
                    { value: "any", label: "Any funding" },
                  ]}
                  value="full"
                  onChange={() => { }}
                />
              </>
            )}
            {section === "Account" && (
              <>
                <Field label="Current password" type="password" placeholder="••••••••" />
                <Field label="New password" type="password" placeholder="••••••••" />
                <label className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3">
                  <span className="text-sm">Email me new scholarship matches</span>
                  <input type="checkbox" defaultChecked className="h-4 w-4 accent-primary" />
                </label>
                <label className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-4 py-3">
                  <span className="text-sm">Deadline reminder emails</span>
                  <input type="checkbox" defaultChecked className="h-4 w-4 accent-primary" />
                </label>
              </>
            )}
          </div>

          <div className="mt-8 flex items-center gap-3">
            <button
              type="button"
              onClick={handleSave}
              className="gradient-primary glow-primary flex items-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90"
            >
              <Save className="h-4 w-4" />
              Save Changes
            </button>
            {saved && (
              <span className="slide-in-right flex items-center gap-1.5 text-sm text-success">
                <CheckCircle2 className="h-4 w-4" />
                Saved!
              </span>
            )}
          </div>
        </div>
      </div>
    </DashboardShell>
  )
}
