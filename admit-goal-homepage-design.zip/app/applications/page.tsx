"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/dashboard-shell"
import { applications as seedApplications, type Application } from "@/lib/data"
import { Plus, ArrowUpRight, Calendar, StickyNote } from "lucide-react"

const STATUSES: Application["status"][] = ["Planning", "Applying", "Submitted", "Accepted", "Rejected"]

const statusStyle: Record<Application["status"], string> = {
  Planning: "text-muted-foreground border-border bg-muted/40",
  Applying: "text-accent border-accent/40 bg-accent/10",
  Submitted: "text-primary border-primary/40 bg-primary/10",
  Accepted: "text-success border-success/40 bg-success/10",
  Rejected: "text-destructive border-destructive/40 bg-destructive/10",
}

export default function ApplicationsPage() {
  const [apps, setApps] = useState<Application[]>(seedApplications)

  function cycleStatus(id: string) {
    setApps((prev) =>
      prev.map((a) => {
        if (a.id !== id) return a
        const next = STATUSES[(STATUSES.indexOf(a.status) + 1) % STATUSES.length]
        return { ...a, status: next }
      }),
    )
  }

  return (
    <DashboardShell>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-balance text-3xl font-bold tracking-tight md:text-4xl">My Applications</h1>
          <p className="mt-2 text-muted-foreground">Track every scholarship you are working on in one place.</p>
        </div>
        <Link
          href="/"
          className="gradient-primary inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
        >
          <Plus className="h-4 w-4" />
          Add Application
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {STATUSES.map((status) => {
          const list = apps.filter((a) => a.status === status)
          return (
            <div key={status} className="flex flex-col gap-3">
              <div className="flex items-center justify-between px-1">
                <span className="text-sm font-semibold">{status}</span>
                <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">
                  {list.length}
                </span>
              </div>
              <div className="flex flex-col gap-3">
                {list.map((app) => (
                  <div key={app.id} className="glass float-card rounded-2xl p-4">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-2xl leading-none" aria-hidden>
                        {app.flag}
                      </span>
                      <button
                        onClick={() => cycleStatus(app.id)}
                        className={`rounded-full border px-2 py-0.5 text-[10px] font-semibold ${statusStyle[app.status]}`}
                      >
                        {app.status}
                      </button>
                    </div>
                    <h3 className="mt-3 text-sm font-semibold leading-snug">{app.name}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{app.university}</p>

                    <div className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Calendar className="h-3.5 w-3.5" />
                      <span>{app.deadline}</span>
                      {app.daysLeft > 0 && (
                        <span className="ml-auto font-medium text-foreground">{app.daysLeft}d left</span>
                      )}
                    </div>

                    <div className="mt-3 flex items-start gap-1.5 rounded-lg bg-muted/40 p-2 text-xs text-muted-foreground">
                      <StickyNote className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                      <span className="leading-relaxed">{app.notes}</span>
                    </div>
                  </div>
                ))}
                {list.length === 0 && (
                  <div className="rounded-2xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground">
                    Nothing here yet
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        Tip: click a status badge to move an application along your pipeline.
      </p>

      <div className="mt-8 text-center">
        <Link
          href="/dashboard"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
        >
          Back to dashboard
          <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    </DashboardShell>
  )
}
