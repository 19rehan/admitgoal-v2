"use client"

import { useState } from "react"
import Link from "next/link"
import { DashboardShell } from "@/components/dashboard-shell"
import { reminders as seedReminders, type Reminder } from "@/lib/data"
import { Bell, BellRing, Calendar, Check, Plus, Trash2, ArrowUpRight } from "lucide-react"

export default function RemindersPage() {
  const [items, setItems] = useState<Reminder[]>(seedReminders)

  function toggleStatus(id: string) {
    setItems((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: r.status === "Active" ? "Sent" : "Active" } : r)),
    )
  }

  function remove(id: string) {
    setItems((prev) => prev.filter((r) => r.id !== id))
  }

  const active = items.filter((r) => r.status === "Active").length

  return (
    <DashboardShell>
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-balance text-3xl font-bold tracking-tight md:text-4xl">Deadline Reminders</h1>
          <p className="mt-2 text-muted-foreground">
            You have <span className="font-semibold text-foreground">{active}</span> active reminder
            {active === 1 ? "" : "s"} keeping you on track.
          </p>
        </div>
        <Link
          href="/"
          className="gradient-primary inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
        >
          <Plus className="h-4 w-4" />
          New Reminder
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {items.map((r) => {
          const isActive = r.status === "Active"
          return (
            <div key={r.id} className="glass float-card flex items-start gap-4 rounded-2xl p-5">
              <div
                className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
                  isActive ? "gradient-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                }`}
              >
                {isActive ? <BellRing className="h-5 w-5" /> : <Bell className="h-5 w-5" />}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-lg leading-none" aria-hidden>
                    {r.flag}
                  </span>
                  <h3 className="truncate text-sm font-semibold">{r.name}</h3>
                </div>
                <p className="mt-0.5 truncate text-xs text-muted-foreground">{r.university}</p>

                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                  <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 font-medium text-muted-foreground">
                    <Bell className="h-3 w-3" />
                    {r.timing}
                  </span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 font-medium text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    {r.deadline}
                  </span>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <button
                    onClick={() => toggleStatus(r.id)}
                    className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors ${
                      isActive
                        ? "border-success/40 bg-success/10 text-success hover:bg-success/20"
                        : "border-border text-muted-foreground hover:bg-muted"
                    }`}
                  >
                    <Check className="h-3.5 w-3.5" />
                    {isActive ? "Mark as sent" : "Reactivate"}
                  </button>
                  <button
                    onClick={() => remove(r.id)}
                    aria-label={`Delete reminder for ${r.name}`}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-muted-foreground transition-colors hover:border-destructive/40 hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {items.length === 0 && (
        <div className="glass mt-4 rounded-2xl p-12 text-center">
          <Bell className="mx-auto h-10 w-10 text-muted-foreground" />
          <h3 className="mt-4 text-lg font-semibold">No reminders set</h3>
          <p className="mt-1 text-sm text-muted-foreground">Add a reminder so you never miss a deadline.</p>
        </div>
      )}

      <div className="mt-8 text-center">
        <Link
          href="/dashboard"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
        >
          Back to dashboard
          <ArrowUpRight className="h-4 w-4" />
        </Link>
      </div>
    </DashboardShell>
  )
}
